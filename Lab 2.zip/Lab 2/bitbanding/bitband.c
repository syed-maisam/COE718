#include "LPC17xx.h"
#include "GLCD.h"
#include "bitband.h"
#include <stdio.h>
#include   "Board_Joystick.h"

//------- ITM Stimulus Port definitions for printf ------------------- //
#define ITM_Port8(n)    (*((volatile unsigned char *)(0xE0000000+4*n)))
#define ITM_Port16(n)   (*((volatile unsigned short*)(0xE0000000+4*n)))
#define ITM_Port32(n)   (*((volatile unsigned long *)(0xE0000000+4*n)))
#define __FI      1
#define __USE_LCD 0

#define DEMCR           (*((volatile unsigned long *)(0xE000EDFC)))
#define TRCENA          0x01000000

struct __FILE { int handle;  };
FILE __stdout;
FILE __stdin;
char text[10];

int fputc(int ch, FILE *f) {
  if (DEMCR & TRCENA) {
    while (ITM_Port32(0) == 0);
    ITM_Port8(0) = ch;
  }
  return(ch);
}

#define ADDRESS(x)    (*((volatile unsigned long *)(x)))
#define BitBand(x, y) 	ADDRESS(((unsigned long)(x) & 0xF0000000) | 0x02000000 |(((unsigned long)(x) & 0x000FFFFF) << 5) | ((y) << 2))

volatile unsigned long * bit1;
volatile unsigned long * bit2;
volatile unsigned long * bit3;
volatile unsigned long * bit4;

#define FIODIR_Bit29  (*((volatile unsigned long *)0x233806F4))
	
#define FIODIR_Bit2   (*((volatile unsigned long *)0x23380A88))

void delay(int ms){
	int count;
	for(count = 0; count < ms; count++)
	{
			count++;
	} 
}	

int main(void){
	Joystick_Initialize();
	LPC_SC->PCONP |= (1 << 15); 
	LPC_GPIO1->FIODIR  |=  (1UL << 29);
	LPC_GPIO1->FIODIR  |=  (1UL << 2);

	
	#ifdef __USE_LCD
		GLCD_Init();
		LPC_SC->PCONP |= (1 << 15); 
		LPC_GPIO1->FIODIR |= 0xB0000000;
		LPC_GPIO2->FIODIR |= 0x0000007C; 
		
		GLCD_Clear(White);
		GLCD_SetBackColor(White);
		GLCD_SetTextColor(Blue);
		GLCD_DisplayString(0,0, __FI, "  COE718 Lab2 Demo  ");

	#endif 
	while(1){
		
		uint32_t joystick_val = 0;
		joystick_val = Joystick_GetState();
		//mask mode
		if(joystick_val == JOYSTICK_DOWN){
			GLCD_DisplayString(6,0, __FI, "Masking Mode  ");	

			
			LPC_GPIO1->FIOPIN |=  ( 1UL << 29);
			LPC_GPIO2->FIOPIN |= ( 1UL << 2);	
			delay(10000000);	    
			LPC_GPIO1->FIOPIN &= ~( 1UL << 29);              
			LPC_GPIO2->FIOPIN &= ~( 1UL << 2); 	
		}
		
		//function mode	
		if(joystick_val == JOYSTICK_UP){
			GLCD_DisplayString(6,0, __FI, "Function Mode ");
			printf("\nfunction mode\n");
			bit1 = &BitBand(&LPC_GPIO1->FIOPIN, 29);
			bit2 = &BitBand(&LPC_GPIO2->FIOPIN, 2);
			*bit1 = 1;
			*bit2 = 1;
			delay(10000000);
			*bit1 = 0;
			*bit2 = 0;
		}
		
		//bit band mode
		if(joystick_val == JOYSTICK_LEFT){
			GLCD_DisplayString(6,0, __FI, "BitBand mode  ");
			FIODIR_Bit29= 1; 
			FIODIR_Bit2 = 1; 
			delay(10000000);
			FIODIR_Bit29 = 0;
			FIODIR_Bit2 =0;
		}
		
		//barrel shifter
		if(joystick_val == JOYSTICK_RIGHT){
				GLCD_DisplayString(6, 0, __FI, "Barrel Shifter App ");

				uint32_t A = 6;
				uint32_t shiftAmount = 3; 
				uint32_t result = A << shiftAmount;

				char equation[30];
				char valueStr[30];

				sprintf(equation, "A = %lu", A);
				sprintf(valueStr, "A<<%lu = %lu", shiftAmount, result);

				GLCD_SetTextColor(DarkGreen);
				GLCD_DisplayString(7, 0, __FI, "Mult by Power of 3");
				GLCD_DisplayString(8, 0, __FI, equation);
				GLCD_DisplayString(9, 0, __FI, valueStr);

		}
			
	} 
		return 0;
}
