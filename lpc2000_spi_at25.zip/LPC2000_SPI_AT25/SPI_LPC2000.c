/*----------------------------------------------------------------------------
 * Name:    SPI_LPC2000.c
 * Purpose: Serial Peripheral Interface Driver for NXP LPC2000
 * Version: V1.00
 * Note(s):
 *----------------------------------------------------------------------------
 * This file is part of the uVision/ARM development tools.
 * This software may only be used under the terms of a valid, current,
 * end user licence from KEIL for a compatible version of KEIL software
 * development tools. Nothing else gives you the right to use this software.
 *
 * This software is supplied "AS IS" without warranties of any kind.
 *
 * Copyright (c) 2008 Keil - An ARM Company. All rights reserved.
 *----------------------------------------------------------------------------
 * History:
 *          V1.00 Initial Version
 *----------------------------------------------------------------------------*/

#include <LPC213X.H>
#include "SPI.H"


/* Initialize and enable the SPI Interface module */
void SPI_Init (void) {

  /* SCK, MISO, MOSI are SPI pins */
  PINSEL1 &= ~0x000000FC;
  PINSEL1 |=  0x000000A8;

  /* SS is GPIO, output set to high */
  IOSET1  = 0x00100000;
  IODIR1 |= 0x00100000;

  /* Enable SPI in Master Mode, 8-bit, CPOL=0, CPHA=0 with Clk Div=8 */
  SSPCR0  = 0x0007;
  SSPCR1  = 0x02;
  SSPCPSR = 0x08;
}


/* Enable/Disable SPI Chip Select */
void SPI_SS (unsigned char ss) {
  if (ss) {
    IOSET1 = 0x00100000;
  } else {
    IOCLR1 = 0x00100000;
  }
}


/* Write and Read a byte on SPI interface */
unsigned char SPI_Transfer (unsigned char outb) {
  unsigned char inb;

  /* Wait if TFE not set, Tx FIFO is not empty */
  while ((SSPSR & 0x01) == 0);
  SSPDR = outb;

  /* Wait if RNE not set, Rx FIFO is empty */
  while ((SSPSR & 0x04) == 0);
  inb = SSPDR;

  return (inb);
}
