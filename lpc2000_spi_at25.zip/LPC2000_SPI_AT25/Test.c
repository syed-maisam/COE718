/*----------------------------------------------------------------------------
 * Name:    Test.c
 * Purpose: AT25 SPI EEPROM on LPC2000 Test
 * Version: V1.00
 * Note(s):
 *----------------------------------------------------------------------------
 * This file is part of the uVision/ARM development tools.
 * This software may only be used under the terms of a valid, current,
 * end user licence from KEIL for a compatible version of KEIL software
 * development tools. Nothing else gives you the right to use this software.
 *
 * This software is supplied "AS IS" without warranties of any kind.
 *
 * Copyright (c) 2008 Keil - An ARM Company. All rights reserved.
 *----------------------------------------------------------------------------
 * History:
 *          V1.00 Initial Version
 *----------------------------------------------------------------------------*/

#include <LPC213X.H>
#include "SPI.H"

unsigned char Buf[256];

int main (void) {

  SPI_Init();

  SPI_MemWrite(0x400, 36,  "Testing AT25 SPI Flash on LPC2138 ...");
  SPI_MemWrite(0x450, 21,  "Page Offset 0x10: ...");
  SPI_MemRead (0x400, 128, Buf);

  while (1);  // Loop forever
}
