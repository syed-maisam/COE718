/*----------------------------------------------------------------------------
 * Name:    SPI_AT25.c
 * Purpose: AT25 SPI EEPROM Driver
 * Version: V1.00
 * Note(s):
 *----------------------------------------------------------------------------
 * This file is part of the uVision/ARM development tools.
 * This software may only be used under the terms of a valid, current,
 * end user licence from KEIL for a compatible version of KEIL software
 * development tools. Nothing else gives you the right to use this software.
 *
 * This software is supplied "AS IS" without warranties of any kind.
 *
 * Copyright (c) 2008 Keil - An ARM Company. All rights reserved.
 *----------------------------------------------------------------------------
 * History:
 *          V1.00 Initial Version
 *----------------------------------------------------------------------------*/

#include "SPI.H"

/* SPI Instructions */
#define SPI_WREN        0x06
#define SPI_WRDI        0x04
#define SPI_RDSR        0x05
#define SPI_WRSR        0x01
#define SPI_READ        0x03
#define SPI_WRITE       0x02

/* Status Register Bits */
#define SR_NRDY         0x01
#define SR_WEN          0x02
#define SR_BP0          0x04
#define SR_BP1          0x08
#define SR_WPEN         0x80

#define PAGE_SZ         64


void SPI_MemRead (unsigned long adr, unsigned long sz, unsigned char *buf) {
  unsigned int i;

  SPI_SS(0);
  SPI_Transfer(SPI_READ);
  SPI_Transfer((unsigned char)(adr >> 8));
  SPI_Transfer((unsigned char)(adr >> 0));
  for (i = 0; i < sz; i++) {
    *buf++ = SPI_Transfer(0xFF);
  }
  SPI_SS(1);
}


void SPI_MemWrite (unsigned long adr, unsigned long sz, unsigned char *buf) {
  unsigned char sr;
  unsigned int  i, n;

  while (sz) {

    n = PAGE_SZ - (adr & (PAGE_SZ - 1));
    if (sz < n) n = sz;

    SPI_SS(0);
    SPI_Transfer(SPI_WREN);
    SPI_SS(1);

    SPI_SS(0);
    SPI_Transfer(SPI_WRITE);
    SPI_Transfer((unsigned char)(adr >> 8));
    SPI_Transfer((unsigned char)(adr >> 0));
    for (i = 0; i < n; i++) {
      SPI_Transfer(*buf++);      
    }
    SPI_SS(1);

    do {
      SPI_SS(0);
      SPI_Transfer(SPI_RDSR);
      sr = SPI_Transfer(0xFF);
      SPI_SS(1);
    } while (sr & SR_NRDY);

    adr += n;
    sz  -= n;

  }
}
