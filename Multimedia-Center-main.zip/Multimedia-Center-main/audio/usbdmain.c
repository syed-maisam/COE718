/*----------------------------------------------------------------------------
 * Name:    usbmain.c
 * Purpose: USB Audio Class Demo
 * Version: V1.20
 *----------------------------------------------------------------------------
 *      This software is supplied "AS IS" without any warranties, express,
 *      implied or statutory, including but not limited to the implied
 *      warranties of fitness for purpose, satisfactory quality and
 *      noninfringement. Keil extends you a royalty-free right to reproduce
 *      and distribute executable files created using this software for use
 *      on NXP Semiconductors LPC microcontroller devices only. Nothing else 
 *      gives you the right to use this software.
 *
 * Copyright (c) 2009 Keil - An ARM Company. All rights reserved.
 *---------------------------------------------------------------------------*/

#include "LPC17xx.h"                        /* LPC17xx definitions */
#include "type.h"

#include "usb.h"
#include "usbcfg.h"
#include "usbhw.h"
#include "usbcore.h"
#include "usbaudio.h"
#include "usbdmain.h"
#include "kbd.h"
#include "LED.h"
#include "GLCD.h"


extern  void SystemClockUpdate(void);
extern uint32_t SystemFrequency;  
extern unsigned char MUSIC_pixel_data[];

uint8_t  Mute;                                 /* Mute State */
uint32_t Volume;                               /* Volume Level */
int rep;

#if USB_DMA
uint32_t *InfoBuf = (uint32_t *)(DMA_BUF_ADR);
short *DataBuf = (short *)(DMA_BUF_ADR + 4*P_C);
#else
uint32_t InfoBuf[P_C];
short DataBuf[B_S];                         /* Data Buffer */
#endif

uint16_t  DataOut;                              /* Data Out Index */
uint16_t  DataIn;                               /* Data In Index */

uint8_t   DataRun;                              /* Data Stream Run State */
uint16_t  PotVal;                               /* Potenciometer Value */
uint32_t  VUM;                                  /* VU Meter */
uint32_t  Tick;                                 /* Time Tick */


/*
 * Get Potenciometer Value
 */
 
 void lights(int x){
	 int i;
	 for (i = 0; i <= x; i++) {
      LED_Off(i);
   }
 }

void get_potval (void) {
  uint32_t val;
	LED_Init();

  LPC_ADC->CR |= 0x01000000;              /* Start A/D Conversion */
  do {
    val = LPC_ADC->GDR;                   /* Read A/D Data Register */
  } while ((val & 0x80000000) == 0);      /* Wait for end of A/D Conversion */
  LPC_ADC->CR &= ~0x01000000;             /* Stop A/D Conversion */
  PotVal = ((val >> 8) & 0xF8) +          /* Extract Potenciometer Value */
           ((val >> 7) & 0x08);
	
	if((PotVal > 0) && (PotVal <= 36)){
		LED_On(7);
		lights(6);
	}
	else if((PotVal > 36) && (PotVal <= 72)){
		LED_On(6);
		lights(5);
	}
	else if((PotVal > 72) && (PotVal <= 108)){
		LED_On(5);
		lights(4);
	}
	else if((PotVal > 108) && (PotVal <= 144)){
		LED_On(4);
		lights(3);
	}
	else if((PotVal > 144) && (PotVal <= 180)){
		LED_On(3);
		lights(2);
	}
	else if((PotVal > 180) && (PotVal <= 216)){
		LED_On(2);
		lights(1);
	}
	else if((PotVal > 216) && (PotVal <= 252)){
		LED_On(1);
		lights(0);
	}
	else if(PotVal > 252){
		LED_On(0);
	}
}


/*
 * Timer Counter 0 Interrupt Service Routine
 *   executed each 31.25us (32kHz frequency)
 */

void TIMER0_IRQHandler(void) 
{
	int joystick_input;
  long  val;
  uint32_t cnt;
	rep = 1;
	while(rep){
		joystick_input = get_button();							  /*Recieves the joystick input*/	
		switch(joystick_input){												
			case KBD_LEFT:
					NVIC_SystemReset();                     /*Resets the board*/
				rep = 0;
				break;
			default:
				if (DataRun) {                            /* Data Stream is running */
					val = DataBuf[DataOut];                 /* Get Audio Sample */
					cnt = (DataIn - DataOut) & (B_S - 1);   /* Buffer Data Count */
					if (cnt == (B_S - P_C*P_S)) {           /* Too much Data in Buffer */
						DataOut++;                            /* Skip one Sample */
					}
					if (cnt > (P_C*P_S)) {                  /* Still enough Data in Buffer */
						DataOut++;                            /* Update Data Out Index */
					}
					DataOut &= B_S - 1;                     /* Adjust Buffer Out Index */
					if (val < 0) VUM -= val;                /* Accumulate Neg Value */
					else         VUM += val;                /* Accumulate Pos Value */
					val  *= Volume;                         /* Apply Volume Level */
					val >>= 16;                             /* Adjust Value */
					val  += 0x8000;                         /* Add Bias */
					val  &= 0xFFFF;                         /* Mask Value */
				} else {
					val = 0x8000;                           /* DAC Middle Point */
				}

				if (Mute) {
					val = 0x8000;                           /* DAC Middle Point */
				}

				LPC_DAC->CR = val & 0xFFC0;               /* Set Speaker Output */

				if ((Tick++ & 0x03FF) == 0) {             /* On every 1024th Tick */
					get_potval();                           /* Get Potenciometer Value */
					if (VolCur == 0x8000) {                 /* Check for Minimum Level */
						Volume = 0;                           /* No Sound */
					} else {
						Volume = VolCur * PotVal;             /* Chained Volume Level */
					}
					val = VUM >> 20;                        /* Scale Accumulated Value */
					VUM = 0;                                /* Clear VUM */
					if (val > 7) val = 7;                   /* Limit Value */
				}
				
				LPC_TIM0->IR = 1;                         /* Clear Interrupt Flag */
				rep = 0;			
				break;
			}
	}
}

/*****************************************************************************
**   Main Function  main()
******************************************************************************/
int audio_main (void)
{
	int i,j;
	volatile uint32_t pclkdiv, pclk;
  /* SystemClockUpdate() updates the SystemFrequency variable */
  SystemClockUpdate();
	
  LPC_PINCON->PINSEL1 &=~((0x03<<18)|(0x03<<20));  
  /* P0.25, A0.0, function 01, P0.26 AOUT, function 10 */
  LPC_PINCON->PINSEL1 |= ((0x01<<18)|(0x02<<20));

  /* Enable CLOCK into ADC controller */
  LPC_SC->PCONP |= (1 << 12);

  LPC_ADC->CR = 0x00200E04;		/* ADC: 10-bit AIN2 @ 4MHz */
  LPC_DAC->CR = 0x00008000;		/* DAC Output set to Middle Point */

  /* By default, the PCLKSELx value is zero, thus, the PCLK for
  all the peripherals is 1/4 of the SystemFrequency. */
  /* Bit 2~3 is for TIMER0 */
  pclkdiv = (LPC_SC->PCLKSEL0 >> 2) & 0x03;
  switch ( pclkdiv )
  {
	case 0x00:
	default:
	  pclk = SystemFrequency/4;
	break;
	case 0x01:
	  pclk = SystemFrequency;
	break; 
	case 0x02:
	  pclk = SystemFrequency/2;
	break; 
	case 0x03:
	  pclk = SystemFrequency/8;
	break;
  
	}
	
  LPC_TIM0->MR0 = pclk/DATA_FREQ - 1;	/* TC0 Match Value 0 */
  LPC_TIM0->MCR = 3;					/* TCO Interrupt and Reset on MR0 */
  LPC_TIM0->TCR = 1;					/* TC0 Enable */

	GLCD_Clear(Black);
	GLCD_SetTextColor(White);
	GLCD_DisplayString(0,5,1, "Audio Mode");
	GLCD_DisplayString(1,2,1, "Relax and Chill!");
	GLCD_DisplayString(2,0,1, "________________________");
	GLCD_DisplayString(3,0,1, "Left to stop audio");

	GLCD_Bitmap(70, 105, 180, 135, MUSIC_pixel_data);

	

	
  NVIC_EnableIRQ(TIMER0_IRQn);
	
  USB_Init();				/* USB Initialization */
	NVIC_EnableIRQ(USB_IRQn);               /* enable USB interrupt */
	USB_Reset();
	USB_SetAddress(0);
	USB_Connect(TRUE);		/* USB Connect */
  /********* The main Function is an endless loop ***********/ 
	GLCD_Clear(Black);
	return 0;
}

/******************************************************************************
**                            End Of File
******************************************************************************/
