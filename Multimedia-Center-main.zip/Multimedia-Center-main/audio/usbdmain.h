#ifndef __usbdmain__H 
#define __usbdmain__H
extern int audio_main (void);

#endif
