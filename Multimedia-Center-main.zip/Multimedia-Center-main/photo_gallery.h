extern int image(void); 
